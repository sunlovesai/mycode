package com.maybo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.maybo.dao.SecDao;
import com.maybo.model.Sec;
import com.maybo.service.ISecService;

public class SecServiceImpl implements ISecService {
	@Autowired
private SecDao secDao; 
/* (non-Javadoc)
 * @see com.maybo.service.impl.ISecService#findById(int)
 */
public Sec findById(int id){
	Sec sec=null;
	try{
	sec=secDao.findSecById(id);
	}
	catch(Exception e){
		sec=null;
	}
	return sec;
	}

/* (non-Javadoc)
 * @see com.maybo.service.impl.ISecService#addSec(com.maybo.model.Sec)
 */
@Transactional
public void addSec(Sec sec){
	secDao.addSec(sec);

}
/* (non-Javadoc)
 * @see com.maybo.service.impl.ISecService#deById(int)
 */
@Transactional
public void deById(int id){
	secDao.delSecById(id);
}
/* (non-Javadoc)
 * @see com.maybo.service.impl.ISecService#updateSec(com.maybo.model.Sec)
 */
@Transactional
public void updateSec(Sec sec){
	secDao.updateSec(sec);
}

public List<Sec> findAllSec() {
	List<Sec> secs=null;
	try{
secs=secDao.findAllSec();
	}catch(Exception e){
		secs=null;
	}
	return secs;
}
}
