package com.maybo.service;

import com.maybo.model.Person;

public interface IPersonService {
public void add(Person p1,Person p2);
public Person find(int id);
}